import React from "react";
import PersonList from "./PersonList";

function App() {
  return (
    <div>
      <PersonList />
    </div>
  );
}

export default App;
